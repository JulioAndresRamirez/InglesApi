from rest_framework import viewsets
from .serializers import DataSerializer
from .models import Data



# Create your views here.
class DataViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows users to be viewed or edited.
    """
    queryset = Data.objects.all().order_by('-fecha')
    serializer_class = DataSerializer


