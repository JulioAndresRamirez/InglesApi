from django.apps import AppConfig


class ApiRestConfig(AppConfig):
    name = 'api_rest'
